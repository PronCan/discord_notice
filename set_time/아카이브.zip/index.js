const axios = require("axios");
// import axios from 'axios';
import json from './key.json' assert { type: "JSON"};

//const json = require("./key.json");
const bosam_def = "https://discord.com/api/webhooks/1052100808969310268/spQECP2iG5Ampf47RTAsFw-4jeKqXjD0bGQZ2-rvKT8XZg9kMvMuVXhMdthkhMT_P_6O";
const bosam_poke = "https://discord.com/api/webhooks/1052387986081329183/HVhBNH4XOEw_qxOlNHSIlLU34TtH8hdXH-95_w3plFx54a5H5w0nv46Iq9jbXlhIfdP_";

//const key = json.key;

console.log("aaa", json.bosam_poke);

exports.handler = async(event) => {
    try {
        let date = new Date();
        let endDate = new Date();
        // discord url, content
        // switch(date) {

        // }
        const result = await axios.post(key, {
            "content": "test message"
        });
        console.log("success", result);
    }catch(e) {
        console.err("faild", e);
    }

    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};
